<?php
if (!defined('ABSPATH')) {
  exit;
}
ob_start();
?>

<div class="wrap">
  <style>
    .ab-div p {
      padding: 0px 15px;
      font-size: 15px;
      color: #000;
      margin-top: 0px;
    }

    .ab-div .ab-p {
      padding: 0px 15px;
    }

    .ab-div li {
      font-size: 15px;
      color: #000;
      margin-top: 0px;
      margin-bottom: 10px;
    }

    .ab-div h3 {
      font-size: 16px !important;
      padding-top: 15px !important;
    }

    .ab-div h4 {
      padding: 8px 12px;
      margin-top: 10px !important;
      margin-bottom: 5px !important;
      font-size: 16px !important;
    }

    .ab-div pre {
      padding: 0px 20px;
    }

    .ab-div code {
      font-size: 15px;
      line-height: 2em;
      color: #000;
    }
  </style>
  <h1 class="wp-heading-inline">AB Odoo Connector Dashboard</h1>

  <div id="dashboard-widgets-wrap">
    <div id="" class="metabox-holder">
      <div class="ab-div postbox">
        <h3>AB Odoo Connector About Us</h3>
        <p>AB Odoo Connector empowers your WordPress website by seamlessly integrating with Odoo, an Open Source ERP and CRM system. Unlock the potential of your forms with this powerful plugin that bridges the gap between Odoo and popular form plugins used in WordPress.</p>
        <p>
        With AB Odoo Connector, you gain the flexibility to associate any Odoo model with any supported form type. By mapping form fields to Odoo model fields, data submitted through your website's forms will be effortlessly transmitted to Odoo, ensuring smooth synchronization as per the specified field mapping. Streamline your data management process and keep your WordPress and Odoo systems in perfect harmony with AB Odoo Connector.  <p>
      </div>
    </div>

  </div>
  <div id="">
    <div id="" class="metabox-holder">
      <div class="ab-div postbox">
        <h3>HOW CAN USE</h3>

        <h3>Step 1:</h3>
        <div class="ab-p">
          <ol>
            <li>Go to "AB Odoo Connector" in the WordPress admin menu.</li>
            <li>Click on<a  style="text-decoration: none;"href='<?php echo esc_url(admin_url('admin.php?page=ab_odoo_connector_setting')); ?>'> "Settings"</a> to access the Odoo Server Properties Form.</li>
            <li>Fill in the required Odoo Server properties, such as URL, Database, Username, and Password, in the provided form fields.</li>
          </ol>
        </div>
        <h3>Step 2: </h3>
        <div class="ab-p">
          <ol>
            <li>To use the AB Odoo Connector functionality, call the function <code>ab_odoo_connector();</code> with appropriate arguments.</li>
            <li>Provide the Odoo model name as the first argument, <br>for example: <code>$model = 'res.partner';</code>.</li>
            <li>Create an array with the field data to be submitted to Odoo. Each field should have a key name corresponding to the Odoo model field, <br> for example: <code>$fields = array('name' => 'AB Demo');</code>.</li>
            <li>Use the <code>ab_odoo_connector()</code> function with the model and fields as arguments to submit data to Odoo, like this:<br>
              <code>ab_odoo_connector($model, $fields);</code>
            </li>
          </ol>
        </div>
        <h3>PHP Code:</h3>
        <pre><code>// Example usage of the ab_odoo_connector function .
  $model = 'res.partner';
  $fields = array('name' => 'AB Demo');
  $result= ab_odoo_connector($model, $fields);
  echo $result;</code></pre>

      </div>
    </div>

  </div>
  <div id="">
    <div id="" class="metabox-holder">
      <div class="ab-div postbox">
        <h3>USE WITH CONATCT FORM 7 PLUGIN</h3>

        <h3>Write a Contact Form 7 Plugin Hook Function</h3>
        <p>Add the following code to your functions.php file in your WordPress theme:</p>
        <pre><code>add_action('wpcf7_before_send_mail', 'submit_contact_form_to_odoo', 10, 1);
function submit_contact_form_to_odoo($cf7) {
  if ($cf7->id() == 8) { // add Contact form 7 form Id
    $submission = WPCF7_Submission::get_instance();
    if ($submission) {
      $posted_data = $submission->get_posted_data();
      $your_name = sanitize_text_field($posted_data['your-name']); //Get Input Data
      $your_email = sanitize_email($posted_data['your-email']); //Get Input Data

      // Similar add other input fields
      $model='hr.employee'; // Model name
      $fields = array(
        'name' => $your_name, // map with Odoo fields
        'work_email' => $your_email,
      );
      ab_odoo_connector( $model, $fields);
    }
  }
}</code></pre>

      </div>
    </div>

  </div>

  <div id="">
    <div id="" class="metabox-holder">
      <div class="ab-div postbox">
        <h3>USE WITH GRAVITY FORM </h3>
        <h3>Write a Gravity Form Plugin Hook Function</h3>
        <p>Add the following code to your theme's functions.php file or a custom plugin file:</p>

        <pre><code>// Handle form submission from Gravity Form with ID "1".
add_action('gform_after_submission_1', 'submit_gravity_form_to_odoo', 10, 2);
function submit_gravity_form_to_odoo($entry, $form) {
    // Get form data from Gravity Forms submission.
    $your_name = rgar($entry, '1');
    $your_email = rgar($entry, '3');

    $model_name = 'hr.employee';
    $fields = array(
        'name' => $your_name,
        'work_email' => $your_email,
    );
    $result = ab_odoo_connector($model_name, $fields);
}</code></pre>

        <p>In the provided code, we use the <code>add_action()</code> function to hook into the Gravity Form with ID "1" after form submission. The <code>submit_gravity_form_to_odoo()</code> function will be called when the form is submitted. The function extracts form data using the <code>rgar()</code> function from the Gravity Forms submission and prepares the data to be submitted to Odoo using the <code>ab_odoo_connector()</code> function.</p>


      </div>
    </div>

  </div>

  <div id="">
    <div id="" class="metabox-holder">
      <div class="ab-div postbox">
      <h3>Simillar integrate with other form plugin</h3>
  <p>
    To integrate the AB Odoo Connector with other form plugins or for more details, please contact the plugin developer Amit Bhardwaj.
  </p>
  <p>
    Developer: Amit Bhardwaj<br>
    Email: <a href="mailto:bhardwajamit0193@gmail.com" target="_blank">bhardwajamit0193@gmail.com</a>
  </p>
    </div>

  </div>

  <?php
  $content = ob_get_clean();
  echo $content;
  ?>