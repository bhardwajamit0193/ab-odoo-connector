<?php
if (!defined('ABSPATH')) {
  exit;
}
ob_start();
?>

<div class="wrap">
  <h1 class="wp-heading-inline">AB Odoo Connector Setting</h1>

  <div id="dashboard-widgets-wrap">
    <div id="dashboard-widgets" class="metabox-holder">
      <div id="postbox-container-1" class="postbox-container">
        <div class="meta-box-sortables ui-sortable">
          <div class="postbox  hide-if-js" style="display: block;">
            <div class="postbox-header">
              <h2 class="hndle ui-sortable-handle"><span class="">Odoo Server Properties</span> </h2>
            </div>
            <div class="inside">

              <form name="post" action="" method="post" id="quick-press" class="initial-form ">
                <?php wp_nonce_field('ab_odoo_connector_nonce', 'ab_odoo_connector_nonce'); ?>

                <div class="input-text-wrap" style="margin-top: 12px;">
                  <label for="url">
                    URL </label>
                  <input type="url" name="ab_url" id="ab_url" autocomplete="off" value="<?php echo esc_attr(get_option('ab_odoo_connector_url')); ?>" required>
                </div>
                <div class="input-text-wrap" style="margin-top: 12px;">
                  <label for="ab_database">
                    Database </label>
                  <input type="text" name="ab_database" id="ab_database" autocomplete="off" value="<?php echo esc_attr(get_option('ab_odoo_connector_db')); ?>" required>
                </div>
                <div class="input-text-wrap" style="margin-top: 12px;">
                  <label for="ab_username">
                    Username</label>
                  <input type="text" name="ab_username" id="ab_username" autocomplete="off" value="<?php echo esc_attr(get_option('ab_odoo_connector_username')); ?>" required>
                </div>
                <div class="input-text-wrap" style="margin-top: 12px;">
                  <label for="ab_password">
                    Password </label>
                  <input type="text" name="ab_password" id="ab_password" autocomplete="off" value="<?php echo esc_attr(get_option('ab_odoo_connector_password')); ?>" required>
                </div>



                <p class="submit" style="margin-top: 12px;">

                  <input type="submit" name="save" id="save-post" class="button button-primary" value="Save"> <br class="clear">
                </p>

              </form>
            </div>
          </div>
        </div>
      </div>


      <div id="postbox-container-2" class="postbox-container">
        <div class="meta-box-sortables ui-sortable">
          <div class="postbox  hide-if-js" style="display: block;">
            <div class="postbox-header">
              <h2 class="hndle ui-sortable-handle"><span class=""> Check with Test Form </span> </h2>
            </div>
            <div class="inside">
              <?php

              if (isset($_SESSION['ab_result'])) {

                $result = $_SESSION['ab_result'];
                if (is_numeric($result)) {
                  echo '<div class="notice notice-success is-dismissible">';
                  echo '<p>Successfully created ID: ' . esc_html($result) . '</p>';
                  echo '</div>';
                } else {
                  echo '<div class="notice notice-error is-dismissible">';
                  echo '<p>' . esc_html($result) . '</p>';
                  echo '</div>';
                }
              }
              ?>

              <form name="post" action="" method="post" id="model-tes" class="initial-form ">
                <?php wp_nonce_field('ab_odoo_connector_test', 'ab_odoo_connector_test'); ?>

                <div class="input-text-wrap" style="margin-top: 12px;">
                  <label for="model">
                    Model </label>
                  <input type="text" name="ab_model" id="ab_model" autocomplete="off" value="<?php echo esc_attr(get_option('ab_odoo_connector_model', 'res.partner')); ?>" required>
                </div>
                <div class="input-text-wrap" style="margin-top: 12px;">
                  <label for="ab_fname">
                    Name (Field Key )</label>
                  <input type="text" name="ab_fname" id="ab_fname" autocomplete="off" value="<?php echo esc_attr(get_option('ab_odoo_connector_fname', 'AB Odoo Test')); ?>" required>
                </div>

                <p class="submit" style="margin-top: 12px;">

                  <input type="submit" name="save" class="button button-primary" value="Send"> <br class="clear">
                </p>

              </form>
            </div>
          </div>
          <div id="side-sortables" class="meta-box-sortables ui-sortable" data-emptystring="Drag boxes here">


            <div id="dashboard_primary" class="postbox hide-if-js" style="display: block;">
              <div class="postbox-header">
                <h2 class="hndle ui-sortable-handle">How to Use AB Odoo Connector</h2>
              </div>
              <div class="inside" style="padding: 0px 15px">
                <p>
                  To get started with AB Odoo Connector and seamlessly integrate your forms with Odoo, follow these simple steps:
                </p>
                <ol>
                  <li>Go to the <a href="<?php echo esc_url(admin_url('admin.php?page=ab_odoo_connector_dashboard')); ?>">AB Odoo Connector Dashboard</a>.</li>
                  <li>Click on "Settings" to fill in the required Odoo Server Properties, such as URL, Database, Username, and Password.</li>
                  <li>Call the function <code>ab_odoo_connector()</code> with appropriate arguments in your shortcode or form.</li>
                  <li>Enjoy the effortless data submission from your forms to Odoo!</li>
                </ol>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>

  </div>

  <?php
  $content = ob_get_clean();
  echo $content;
  ?>