<?php

/**
 * Plugin Name: AB Odoo Connector
 * Description: Seamlessly integrate Odoo with your WordPress website using  a function ab_odoo_connector() in this user-friendly plugin. Simplify data submission to Odoo through your website's forms effortlessly.
 * Version: 2.0
 * Author: Amit Bhardwaj
 * Author URI: https://www.linkedin.com/in/amit-bhardwaj-0193/
 * License: GPL-2.0+
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 */

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit;
}


add_action('admin_init', 'ab_handle_odoo_connector_form_submission');
function ab_handle_odoo_connector_form_submission() {
    if (isset($_POST['save']) && isset($_POST['ab_odoo_connector_nonce']) && wp_verify_nonce($_POST['ab_odoo_connector_nonce'], 'ab_odoo_connector_nonce')) {
        update_option('ab_odoo_connector_url', sanitize_text_field($_POST['ab_url']));
        update_option('ab_odoo_connector_db', sanitize_text_field($_POST['ab_database']));
        update_option('ab_odoo_connector_username', sanitize_text_field($_POST['ab_username']));
        update_option('ab_odoo_connector_password', sanitize_text_field($_POST['ab_password']));

    }
}


// Check if the Odoo Connector plugin is active.
function is_odoo_connector_active()
{
    $active_plugins = get_option('active_plugins');
    return in_array('ab-odoo-connector/ab-odoo-connector.php', $active_plugins);
}

// Odoo connector function.

function ab_odoo_connector($model_name, $fields)
{

    if (is_odoo_connector_active()) {

        $url = get_option('ab_odoo_connector_url', ''); // Default to an empty string if not set.
        $db = get_option('ab_odoo_connector_db', '');
        $username = get_option('ab_odoo_connector_username', '');
        $password = get_option('ab_odoo_connector_password', '');
    
        // Sanitize the form data if needed.
        $url = esc_url_raw($url);
        $db = sanitize_text_field($db);
        $username = sanitize_text_field($username);
        $password = sanitize_text_field($password);

        $model = isset($model_name) ? sanitize_text_field($model_name) : '';

        if (empty($url) || empty($db) || empty($username) || empty($password) || empty($model)) {
            return 'Error: Invalid or missing parameters ';
        } else {
            $url_auth = $url . '/xmlrpc/2/common';
            $url_exec = $url . '/xmlrpc/2/object';
            $fields = array_map('sanitize_text_field', $fields);

            if (!class_exists('ripcord')) {
                require_once(plugin_dir_path(__FILE__) . 'ripcord/ripcord.php');
            }

            $common = ripcord::client($url_auth);
            $uid = $common->authenticate($db, $username, $password, array());

            $models = ripcord::client($url_exec);
            $result = $models->execute_kw($db, $uid, $password, $model, 'create', array($fields));
            if (is_array($result) && array_key_exists('faultCode', $result) && array_key_exists('faultString', $result)) {
                return 'Error: ' . $result['faultString'];
            } else {
                return $result;
            }
        }
    } else {

        return 'Odoo Connector plugin is not active.';
    }
}



add_action('admin_menu', 'odoo_connector_add_dashboard_page');
function odoo_connector_add_dashboard_page() {
    add_menu_page(
        'AB Odoo Connector Dashboard',    
        'AB Odoo Connector',            
        'manage_options',              
        'ab_odoo_connector_dashboard',    
        'ab_odoo_connector_about_page', 
        'dashicons-feedback',     
        4                          
    );
    add_submenu_page(
        'ab_odoo_connector_dashboard',
        'AB Odoo Connector Dashboard',
        'Dashboard',
        'manage_options',
        'ab_odoo_connector_dashboard',  
        'ab_odoo_connector_about_page', 

      );
    add_submenu_page(
        'ab_odoo_connector_dashboard',
        'AB Odoo Connector Setting',
        'Setting',
        'manage_options',
        'ab_odoo_connector_setting',  
        'ab_odoo_connector_setting_page', 

      );
}


function ab_odoo_connector_about_page() {

    if (!current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions to access this page.'));
    }

 
    require_once(plugin_dir_path(__FILE__) . 'ab-dashboard-template.php');
}
function ab_odoo_connector_setting_page() {

    if (!current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions to access this page.'));
    }

 
    require_once(plugin_dir_path(__FILE__) . 'ab-setting-template.php');
}




add_action('admin_init', 'ab_handle_odoo_connector_form_test');
function ab_handle_odoo_connector_form_test() {
   
    if (isset($_POST['save']) && isset($_POST['ab_odoo_connector_test']) && wp_verify_nonce($_POST['ab_odoo_connector_test'], 'ab_odoo_connector_test')) {
        update_option('ab_odoo_connector_model', sanitize_text_field($_POST['ab_model']));
        update_option('ab_odoo_connector_fname', sanitize_text_field($_POST['ab_fname']));
        $model_name = sanitize_text_field($_POST['ab_model']);
        $fname = sanitize_text_field($_POST['ab_fname']);
        $fields = array(
            'name' => $fname,
        );

        $result = ab_odoo_connector($model_name, $fields);
        unset($_SESSION['ab_result']);
        $_SESSION['ab_result'] = $result;
    }

}

